An Azure CLI Extension to manage functionapp resources


