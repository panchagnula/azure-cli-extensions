# --------------------------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for license information.
# --------------------------------------------------------------------------------------------

NODE_VERSION_DEFAULT = "8.9"
NETCORE_VERSION_DEFAULT = "2.0"
DOTNET_VERSION_DEFAULT = "4.7"
NETCORE_RUNTIME_NAME = "dotnetcore"
DOTNET_RUNTIME_NAME = "aspnet"
OS_DEFAULT = "Windows"
STATIC_RUNTIME_NAME = "static"  # not an oficial supported runtime but used for CLI logic
# TODO: Remove this once we have the api returning the versions
NODE_VERSIONS = ['4.4', '4.5', '6.2', '6.6', '6.9', '6.11', '8.0', '8.1']
NETCORE_VERSIONS = ['1.0', '1.1', '2.0']
DOTNET_VERSIONS = ['3.5', '4.7']
NODE_RUNTIME_NAME = "node"
